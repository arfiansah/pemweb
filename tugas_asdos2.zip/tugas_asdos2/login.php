<!DOCTYPE html>
<html>
<head>
<title>Pratikum Pemrograman WEB</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">

  <link rel="stylesheet" type="text/css" href="dist/components/container.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">
  <link rel="stylesheet" type="text/css" href="dist/components/header.css">
  <link rel="stylesheet" type="text/css" href="dist/components/image.css">
  <link rel="stylesheet" type="text/css" href="dist/components/menu.css">
  <link rel="stylesheet" type="text/css" href="dist/components/divider.css">
  <link rel="stylesheet" type="text/css" href="dist/components/segment.css">
  <link rel="stylesheet" type="text/css" href="dist/components/form.css">
  <link rel="stylesheet" type="text/css" href="dist/components/input.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/list.css">
  <link rel="stylesheet" type="text/css" href="dist/components/message.css">
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">

<?php
require 'koneksi.php';
session_start();
if (isset($_POST['submit'])) {
      $username = $_POST['username'];
      $password = $_POST['password'];
      $query = mysql_query("SELECT * FROM login WHERE username =
      '$username' LIMIT 1");
      $hasil = mysql_fetch_array($query);
      if (password_verify($password, $hasil['password'])) {
              $_SESSION['username'] = $hasil['username'];
              if($hasil['privilege'] == 1){
                    header('location: ./home_admin.php');
              } else{
                    header('location: ./home_user.php');
              }
              } else {
                    echo 'Invalid password.';
              }
  }
  
?>
  <style type="text/css">
    body {
      background-color: #DADADA;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
  </style>
</head>


<body>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
    <img src="lol.jpg" class="image">
      <div class="content">
        Monggo Log-in Kakak !
      </div>
    </h2>
    <form class="ui large form" method="POST">
      <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" name="username" placeholder="Username">
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Password">
          </div>
        </div>
        <div >
        <input type="submit" name="submit" value="Login" class="ui fluid large teal submit button">
        </div>
      </div>
    </form>

    <div class="ui message">
      Utawi Anyar ? <a href="register.php">Daftar</a>
    </div>
  </div>
</div>

</body>
</html>