-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2017 at 05:40 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
`Berita_id` int(5) NOT NULL,
  `Berita_judul` varchar(100) NOT NULL,
  `Berita_headline` text NOT NULL,
  `Berita_isi` text NOT NULL,
  `Berita_author` varchar(15) NOT NULL,
  `Berita_tanggal` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`Berita_id`, `Berita_judul`, `Berita_headline`, `Berita_isi`, `Berita_author`, `Berita_tanggal`) VALUES
(4, 'Soleram', 'Anak yang manis', 'Anak manis janganlah di cium sayang kalau dicium merahlah pipinya', 'Paijon', '2017-04-01 05:38:26'),
(5, 'Bahagia', 'Itu sederhana', 'Tapi ada kalanya bahagia itu sangat kompleks', 'Putri Marino', '2017-03-31 14:49:16'),
(6, 'Ibu', 'Surga', 'Katanya surga itu dibawah telapak kaki ibu', 'Orang bilang', '2017-03-31 14:49:49'),
(7, 'Makan', 'Penting', 'Katanya makan itu penting', 'Luffy', '2017-03-31 14:50:29'),
(8, 'Thailand', 'Suka makan pecel', 'Ada warga Thailand yang mampir di Indonesia makan pecel', 'Fitre', '2017-04-01 05:38:17');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
`id` int(5) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(70) NOT NULL,
  `privilege` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `privilege`) VALUES
(1, 'yayan', '$2y$10$4ZjBCmBf4fcIMjsDe5u49.g0ElZQeNeL/PtxCw2XYEs7BZnNYfdy2', 1),
(2, 'ridwan', '$2y$10$riKENU/2xGl3eH2..qvgIuNs17.CQYf.YS3aEE0xxS7RYtdHzwkDu', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
 ADD PRIMARY KEY (`Berita_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
MODIFY `Berita_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
