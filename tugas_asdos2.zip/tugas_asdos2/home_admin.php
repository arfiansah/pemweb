<!DOCTYPE html>
<html>
	<head>
		<title>Pratikum Pemrograman WEB</title>
	</head>
	<style>
		p{
			font-size:400%;
			background-color:lightgreen;
			color:white;
			font-family:calibri;
		}
	</style>
<body style="background:#DADADA">
<?php
	require 'koneksi.php';
	session_start();
	if($_SESSION['username']){
	echo "Home Admin, selamat datang: ".$_SESSION['username'];?>
	<br>
	<p>cetar membahana</p>
	<br>
	<a href="logout.php">Logout</a>
<?php } else{
header('location: ./login.php');
}
?>
</body>
</html>