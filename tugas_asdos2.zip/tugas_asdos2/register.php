<!DOCTYPE html>
<html>
<head>


<script type="text/javascript">
// fungsi yang dipanggil ketika form di submit
// lihat baris 5 
function validasi()
    {
//        menangkap variabel nip dari form, 
//        my form adalah id dari form, lihat baris 5
//        nip adalah id inputan, lihat baris 6
        var username=document.forms["myform"]["username"].value;
        var password=document.forms["myform"]["password"].value;
        
//        membuat variabel numbers bernilai angka 0 s/d 9
        var numbers=/^[0-9]+$/;
        
//        validasi nip tidak boleh kosong (required)
        if (username==null || username=="")
          {
          alert("Username tidak boleh kosong !");
          return false;
          };

         if (password==null || password=="")
          {
          alert("Password tidak boleh kosong !");
          return false;
          };


//         jika ada validasi untuk inputan lain letakkan disini
//        ...
     }
</script>


		<title>Pratikum Pemrograman WEB</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">

  <link rel="stylesheet" type="text/css" href="dist/components/container.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">
  <link rel="stylesheet" type="text/css" href="dist/components/header.css">
  <link rel="stylesheet" type="text/css" href="dist/components/image.css">
  <link rel="stylesheet" type="text/css" href="dist/components/menu.css">
  <link rel="stylesheet" type="text/css" href="dist/components/divider.css">
  <link rel="stylesheet" type="text/css" href="dist/components/segment.css">
  <link rel="stylesheet" type="text/css" href="dist/components/form.css">
  <link rel="stylesheet" type="text/css" href="dist/components/input.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/list.css">
  <link rel="stylesheet" type="text/css" href="dist/components/message.css">
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">
		<?php
require 'koneksi.php';
if (isset($_POST['submit'])) {
		$username = $_POST['username'];
		$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
		$privileges = $_POST['privileges'];
		$query = mysql_query("INSERT into login VALUES('','$username','$password','$privileges')");
		if(query){
			header('location: ./login.php');
		} else{
			echo "Gagal register";
		}
		}
		?>

  <style type="text/css">
    body {
      background-color: #DADADA;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
  </style>

</head>
<body>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <div class="content">
        Monggo Silahken Register!
      </div>
    </h2>
    <form id="myform" class="ui large form" method="POST" onSubmit="return validasi()">
      <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" name="username" placeholder="Username">
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Password">
          </div>
        </div>
        <tr>
							<td class="content">Hak akses</td>
							<td>
								<select name="privileges">
								<option disabled selected>--pilih hak akses--</option>
								<option value="1">Admin</option>
								<option value="0">User biasa</option>
								</select>
							</td>
		</tr>
		<br>
        <div >
        <input type="submit" name="submit" value="Register" class="ui fluid large teal submit button">
        </div>
      </div>
    </form>
    <div class="ui message">
      Utawi Login ? <a href="login.php">Log-in</a>
    </div>

  </div>
</div>
</body>
</html>