<!DOCTYPE html>
<html>
<head>
		<title>CRUD PHP</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">

  <link rel="stylesheet" type="text/css" href="dist/components/container.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">
  <link rel="stylesheet" type="text/css" href="dist/components/header.css">
  <link rel="stylesheet" type="text/css" href="dist/components/image.css">
  <link rel="stylesheet" type="text/css" href="dist/components/menu.css">

  <link rel="stylesheet" type="text/css" href="dist/components/divider.css">
  <link rel="stylesheet" type="text/css" href="dist/components/segment.css">
  <link rel="stylesheet" type="text/css" href="dist/components/form.css">
  <link rel="stylesheet" type="text/css" href="dist/components/input.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/list.css">
  <link rel="stylesheet" type="text/css" href="dist/components/message.css">
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">
		<?php
		require 'koneksi.php';
		if (isset($_POST['submit'])) {
				$berita_judul 			= $_POST['berita_judul'];
				$berita_headline 		= $_POST['berita_headline'];
				$berita_isi 			= $_POST['berita_isi'];
				$berita_author 			= $_POST['berita_author'];
				$berita_tanggal 		= date('Y-m-d H:i:s');
				$query 					= mysql_query("INSERT into berita
						VALUES('','$berita_judul','$berita_headline','$berita_isi',
						'$berita_author', '$berita_tanggal')");
			if($query){
					header('location: ./index.php');
			} else{
					echo "Gagal input";
			}
			}
				?>

  <style type="text/css">

    body {
      background-color: #DADADA;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
    /*p{
    	margin-left:100px;
    	font-family:calibri;
    	font-size:200%;
    	color:blue;
    }*/
  </style>
</head>
<body>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <div class="content">
        Monggo Diisi Beritane Kakak !
      </div>
      <br><div class="content">
        jangan malu malu :)
      </div>
    </h2>
    <form class="ui large form" method="POST">
      <div class="ui stacked segment">
     	Judul Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_judul" placeholder="Judul Beritane Bukan Yang Lain">
          </div>
        </div>
        Headline Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_headline" placeholder="Headline Beritane Bukan Yang Lain">
          </div>
        </div>
        Isi Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_isi" placeholder="Isi Beritane Bukan Yang Lain">
          </div>
        </div>
        Author Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_author" placeholder="Penulis Beritane Bukan Yang Lain">
          </div>
        </div>
        <div >
        <input type="submit" name="submit" value="Simpan" class="ui fluid large teal submit button">
        </div>
      </div>
    </form>

    <div class="ui message">
     <a href="read.php">Lihat Data</a>
    </div>
  </div>
</div>
</body>
</html>