<!DOCTYPE html>
<html>
<head>
		<title>CRUD PHP</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">

  <link rel="stylesheet" type="text/css" href="dist/components/container.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">
  <link rel="stylesheet" type="text/css" href="dist/components/header.css">
  <link rel="stylesheet" type="text/css" href="dist/components/image.css">
  <link rel="stylesheet" type="text/css" href="dist/components/menu.css">

  <link rel="stylesheet" type="text/css" href="dist/components/divider.css">
  <link rel="stylesheet" type="text/css" href="dist/components/segment.css">
  <link rel="stylesheet" type="text/css" href="dist/components/form.css">
  <link rel="stylesheet" type="text/css" href="dist/components/input.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/list.css">
  <link rel="stylesheet" type="text/css" href="dist/components/message.css">
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">
		<?php
		require 'koneksi.php';

		if (isset($_POST['submit'])) {
				$berita_id = $_POST['berita_id'];
				$berita_judul = $_POST['berita_judul'];
				$berita_headline = $_POST['berita_headline'];
				$berita_isi = $_POST['berita_isi'];
				$berita_author = $_POST['berita_author'];
				$berita_tanggal = date('Y-m-d H:i:s');
				$query = mysql_query("UPDATE berita SET
						berita_judul='$berita_judul',
						berita_headline='$berita_headline',
						berita_isi='$berita_isi',
						berita_author='$berita_author',
						berita_tanggal='$berita_tanggal' WHERE
						berita_id='$berita_id'");
				if($query){
						header('location: ./read.php');
				} else{
						echo "Gagal UPDATE";
				}
		}
		if (isset($_GET['berita_id'])) {
				$berita_id = $_GET['berita_id'];
		$query = mysql_query("SELECT * FROM berita WHERE berita_id =
'$berita_id'");
			$hasil = mysql_fetch_array($query);
			?>
  <style type="text/css">

    body {
      background-color: #DADADA;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
    /*p{
    	margin-left:100px;
    	font-family:calibri;
    	font-size:200%;
    	color:blue;
    }*/
  </style>
</head>
	<body>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <div class="content">
        Edit Data Berita Ya !
      </div>
      <br><div class="content">
        jangan malu malu :)
      </div>
    </h2>
    <form class="ui large form" method="POST">
    <input type="hidden" name="berita_id" value="<?php echo $hasil[0] ?>">
      <div class="ui stacked segment">
     	Judul Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_judul" value="<?php echo
		$hasil[1] ?>">
          </div>
        </div>
        Headline Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_headline" value="<?php echo
		$hasil[2] ?>">
          </div>
        </div>
        Isi Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_isi" value="<?php echo
		$hasil[3] ?>">
          </div>
        </div>
        Author Berita
        <div class="field">
          <div class="ui input">
            <input type="text" name="berita_author" value="<?php echo
		$hasil[4] ?>">
          </div>
        </div>
        <div >
        <input type="submit" name="submit" value="Update" class="ui fluid large teal submit button">
        </div>
      </div>
	<?php }?>
    </form>

    <div class="ui message">
     <a href="read.php">Lihat Data</a>
    </div>
  </div>
</div>
	</body>
</html>